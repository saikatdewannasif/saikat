# SECTI
SECTI App This app uses via Saudi Electricity Company to reserve the courses that the company provides it  The user able to create an account and see all courses after that he can see what's the price? what's the suitable date for him?  what's the location near for him?
