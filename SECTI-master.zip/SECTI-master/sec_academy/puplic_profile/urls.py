from django.urls import path, re_path, include
# from .views import SignupView, LoginFormView, LogoutForm
app_name = 'puplic_profile'

urlpatterns = [
    # path('signup/', SignupView, name='signup'),
    # path('login/', LoginFormView, name='login'),
    # path('logout/', LogoutForm, name='logout'),
]
