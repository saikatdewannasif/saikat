from django.apps import AppConfig


class PuplicProfileConfig(AppConfig):
    name = 'puplic_profile'
