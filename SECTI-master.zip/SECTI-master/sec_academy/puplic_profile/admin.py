from django.contrib import admin
from .models import ProfileUser
# Register your models here.
admin.site.register(ProfileUser)
