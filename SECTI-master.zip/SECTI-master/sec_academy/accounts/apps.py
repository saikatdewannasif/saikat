from django.apps import AppConfig


class AcountsConfig(AppConfig):
    name = 'acounts'
