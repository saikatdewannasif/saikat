from django.contrib import admin
from .models import OrdersModel
# Register your models here.
admin.site.register(OrdersModel)