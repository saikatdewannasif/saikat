from django.urls import path, include, re_path

app_name = "orders"

urlpatterns = [
    
]
