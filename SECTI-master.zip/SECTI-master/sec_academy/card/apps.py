from django.apps import AppConfig


class CardConfig(AppConfig):
    name = 'card'
